# exercise-app

Complete 7 different exercises that can be timed or counted.

Check off exrcises that have been completed.

Enter the total minutes spent exercising.

It can be found here: 

https://julianamacedo1.github.io/exercise-app/

