import PageController from "../../js/components/PageController/index.js";

PageController.initialize();