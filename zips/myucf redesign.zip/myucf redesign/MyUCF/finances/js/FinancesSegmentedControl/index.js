import SegmentedControl from "../../../js/components/SegmentedControl/index.js";

class FinancesSegmentedControl extends SegmentedControl {
    static componentId = "finances-view-selector";
}

export default FinancesSegmentedControl;