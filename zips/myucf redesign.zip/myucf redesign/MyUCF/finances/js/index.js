import PageController from "../../js/components/PageController/index.js";
import FinancesSegmentedControl from "./FinancesSegmentedControl/index.js";

PageController.initialize();
FinancesSegmentedControl.initialize();