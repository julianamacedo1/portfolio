import SegmentedControl from "../../../js/components/SegmentedControl/index.js";

class AcademicPageSegmentedControl extends SegmentedControl {
    static componentId = "academic-page-selector";
}

export default AcademicPageSegmentedControl;