import DropdownMenu from "../../../js/components/DropdownMenu/index.js";

class SemesterClassesDropdownMenu extends DropdownMenu {
    static componentId = "semester-classes-selector";
}

export default SemesterClassesDropdownMenu;