import SegmentedControl from "../../../js/components/SegmentedControl/index.js";

class StudentInformationSegmentedControl extends SegmentedControl {
    static componentId = "student-information-selector";
}

export default StudentInformationSegmentedControl;