<?php
    $__local = $_SERVER['HTTP_HOST'] == "localhost";

    $__database = $__local ? "myUCF" : "da400699";
    $__host = $__local ? "localhost" : "net1255.net.ucf.edu";
    $__username = $__local ? "root" : "da400699";
    $__password = $__local ? "" : "Really-Secure-Password123!";