<?php   
    $clothingFilters = [
        "Gender Preference" => [
            "Masculine",
            "Feminine",
        ],
        "Category" => [
            "Shirts",
            "Shorts",
            "Skirts",
            "Pants",
            "Jeans",
            "Dresses",
        ],
        "Brand" => [
            "H&M",
            "Target",
            "Kohls",
            "Forever 21",
            "Nike",
            "Zara",
            "Shein",
            "Nasty Gal",
            "JCPenney",
        ],
        "Fit" => [
            "Regular Fit",
            "Slim Fit",
            "Loose Fit",
            "Relaxed Fit",
        ],
    ];
