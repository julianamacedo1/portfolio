<?php
    $somatotypeData = [
        "Ectomorph" => "Tends to have a lean build, long limbs, and small muscle bellies.",
        "Mesomorph" => "A middle-of-the-road build that takes the best of both worlds.",
        "Endomorph" => "Tends to gain weight and keep it on. Build is wider.",
    ];